Amazon Product Scraper
Um scraper simples que extrai listagens de produtos da primeira página de resultados da Amazon para uma palavra-chave específica.

📋 Pré-requisitos
Node.js (v14 ou superior)

npm (vem com o Node.js)

Conexão com a internet

🛠 Instalação
Clone o repositório ou baixe os arquivos

Navegue até a pasta do backend:

bash
Copy
cd amazon-scraper/backend
Instale as dependências:

bash
Copy
npm install
🚀 Como Executar
Inicie o servidor backend:

bash
Copy
cd backend
npm start
O servidor será iniciado em http://localhost:3000

Acesse a interface no navegador:

Abra http://localhost:3000 no seu navegador

Ou abra diretamente o arquivo frontend/index.html

🖥 Como Usar
Digite uma palavra-chave de busca no campo de entrada (ex: "notebook", "smartphone")

Clique no botão "Buscar Produtos"

Visualize os resultados da primeira página de busca da Amazon

🧩 Estrutura do Projeto
Copy
amazon-scraper/
├── backend/           # Código do servidor Node.js
│   ├── server.js      # Servidor principal e rotas da API
│   └── package.json   # Dependências do projeto
└── frontend/          # Interface do usuário
    ├── index.html     # Página principal
    ├── style.css      # Estilos CSS
    └── script.js      # Lógica do frontend
⚙️ Funcionalidades
Extrai da Amazon:

Título do produto

Classificação por estrelas

Número de avaliações

URL da imagem

Link para o produto

Interface responsiva

Feedback visual durante o carregamento

Tratamento de erros

⚠️ Limitações e Considerações
Pode ser bloqueado pela Amazon se muitas requisições forem feitas

O seletor de elementos HTML pode precisar de atualização se a Amazon mudar sua estrutura

Projeto apenas para fins educacionais

📄 Licença
Este projeto é open-source. Sinta-se livre para usá-lo e modificá-lo conforme necessário.

